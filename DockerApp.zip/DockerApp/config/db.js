const mongoose = require("mongoose");

const connectDB = async () => {
        const conn = await mongoose.connect(
            `mongodb://${process.env.MONGO_USER}:${process.env.MONGO_PASSWORD}@${process.env.MONGO_IP}:${process.env.MONGO_PORT}/tasks-db?authSource=admin`,
            {useNewUrlParser: true, useUnifiedTopology: true}
        );
        console.log('MongoDB Connected :',conn.connection.host);
}

module.exports = {
    connectDB
}