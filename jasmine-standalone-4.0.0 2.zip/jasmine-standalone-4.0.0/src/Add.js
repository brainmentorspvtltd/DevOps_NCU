function add(){
    var sum = 0;
    for(let i = 0; i<arguments.length; i++){
        if(typeof arguments[i] ==='function'){
            arguments[i] = arguments[i]();
        }
        sum+= isNaN(parseInt(arguments[i]))?0:parseInt(arguments[i]);
}    
return sum;
}