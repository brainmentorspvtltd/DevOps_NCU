describe("add testsuite", function(){
    it("should add with 0 args", function(){
        var result = add();
        // expect use for Assertion
        expect(0).toBe(result);
    });
    it("should add with 1 args", function(){
        var result = add(10);
        // expect use for Assertion
        expect(10).toBe(result);
    });
    it("should add with 2 args", function(){
        var result = add(10,20);
        // expect use for Assertion
        expect(30).toBe(result);
    });
    it("should add with 3 args", function(){
        var result = add(1,2,3);
        // expect use for Assertion
        expect(6).toBe(result);
    });
    it("should add with 5 args", function(){
        var result = add(1,2,3,4,5);
        // expect use for Assertion
        expect(15).toBe(result);
    });
    it("should add with 5 string and number mix args", function(){
        var result = add(1,"2",3,"4",5);
        // expect use for Assertion
        expect(15).toBe(result);
    });
    it("should add with 5 string and number mix args", function(){
        var result = add(1,"two","3","four",5);
        // expect use for Assertion
        expect(9).toBe(result);
    });
    it("should add with  string, function and number mix args", function(){
        var result = add(1,"two",three,four,"5");
        // expect use for Assertion
        expect(13).toBe(result);
    });
});
function four(){
    return 4;
}
function three(){
    return "3";

}